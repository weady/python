#!/bin/bash
# chkconfig:   - 85 15
# description: ops celery

export C_FORCE_ROOT="true"
cd /home/appdeploy/AutoDeploy

start_cmd="/home/appdeploy/AutoDeploy/venv/bin/celery  -A mysite worker -l INFO >> /tmp/auto_celery.log 2>&1 &"
ps_keyword="celery worker"
ensure_dir=""

service_name=$( /bin/echo $0 | /bin/awk -F/ '{print $NF}' )
get_pid()
{
    [ -z "${ps_keyword}" ] && /bin/echo "Cannot find \${ps_keyword}" && exit
    ps_cmd="/bin/ps -ef | /bin/grep -v grep"
    for var in ${ps_keyword} ; do
        ps_cmd="${ps_cmd} | /bin/grep ${var}"
    done
    ps_cmd="${ps_cmd} | /bin/awk '{print \$2}'"
    eval ${ps_cmd}

}
mkdir_p()
{
    [ -z "${ensure_dir}" ] || for var in ${ensure_dir} ; do [ -d ${var} ] || /bin/mkdir -p ${var} ; done
}
start()
{
    [ ! -z "$(get_pid)" ] && /bin/echo "${service_name} is running..." && exit
    mkdir_p
    eval ${start_cmd}
    [ $? -ne 0 ] && /bin/echo "${service_name} start error" && exit || /bin/echo "${service_name} start"
}
stop()
{
    [ ! -z "$(get_pid)" ] && /bin/kill $(get_pid)
    kill_status=0
    for var in {1..10} ; do
        [ -z "$(get_pid)" ] && kill_status=1 && break
        /bin/sleep 1
    done
    [ ${kill_status} -eq 0 ] && /bin/echo "${service_name} stop error" && exit || /bin/echo "${service_name} stop"
}
status()
{
    pids=$( /bin/echo $(get_pid) | /bin/sed 's#\n# #g' )
    [ ! -z "${pids}" ] && /bin/echo -e "${service_name} is running. Pid is ${pids}." || /bin/echo "${service_name} is stopped."
}
restart()
{
    stop
    start
}
case $1 in
    start)
        start;;
    stop)
        stop;;
    status)
        status;;
    restart)
        restart;;
    *)
        /bin/echo "Usage: $0 {start|stop|status|restart}";;
esac
