#! /bin/bash

NAME=AUTO
DESC="AUTO uwsgi daemon"

d_start() {
    /home/appdeploy/AutoDeploy/venv/bin/uwsgi -x /home/appdeploy/AutoDeploy/socket.xml
  }

d_stop() {
    for pid in $(ps aux|grep /home/appdeploy/AutoDeploy/venv/bin/uwsgi|awk '{print $2}')
    do
        kill -9 $pid >/dev/null 2>1&
    done
  }

case "$1" in
  start)
  	echo -n "Starting $DESC: $NAME"
  	d_start
  	echo "."
	;;
  stop)
  	echo -n "Stopping $DESC: $NAME"
  	d_stop
  	echo "."
	;;
  restart)
  	echo -n "Restarting $DESC: $NAME"
  	d_stop
  	sleep 1
  	d_start
  	echo "."
	;;
  *)
	  echo "Usage: $SCRIPTNAME {start|stop|restart}" >&2
	  exit 3
	;;
esac

exit 0
