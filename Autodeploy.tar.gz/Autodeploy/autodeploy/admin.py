from django.contrib import admin

# Register your models here.

from . import models

admin.site.register(models.App_deploy_batch)
admin.site.register(models.Permission)