#!/usr/bin/python
#coding:utf8
#	by wangdd 2017/03/23

import paramiko
import sys,os,time
import re
import logging

from django.conf import settings

#封装的日志类
class Logger:
	def __init__(self,path,clevel = logging.DEBUG,Flevel = logging.DEBUG):
		self.logger = logging.getLogger(path)
		self.logger.setLevel(logging.DEBUG)
		fmt = logging.Formatter('[%(asctime)s] [%(levelname)s] %(message)s', '%Y-%m-%d %H:%M:%S')
		#设置CMD日志
		sh = logging.StreamHandler()
		sh.setFormatter(fmt)
		sh.setLevel(clevel)
		#设置文件日志
		fh = logging.FileHandler(path)
		fh.setFormatter(fmt)
		fh.setLevel(Flevel)
		
		# self.logger.addHandler(sh)
		self.logger.addHandler(fh)

	def debug(self,message):
		self.logger.debug(message)

	
	def info(self,message):
		self.logger.info(message)

	def warn(self,message):
		self.logger.warn(message)

	def error(self,message):
		self.logger.error(message)

	def cri(self,message):
		self.logger.critical(message)

#登陆ansible服务器，然后在执行命令
def exec_install(softname,hostfile,configfile,logfile,softversion):
	'''
	host:ansible 服务器IP
	user:登录ansible的用户
	passwd:登录ansible的密码
	softname:中间件的名称
	hostfile:生成的ansible的临时文件
	configfile:生成的中间件的临时文件
	logfile:部署的日志文件
	'''


	if len(softversion.split('-')) == 2:
		version_num = softversion.split('-')[1]
	else:
		version_num = None

	logfile = logfile
	loginfo = Logger(logfile,logging.INFO, logging.INFO)

	ANSIBLE_INFO = settings.ANSIBLE_INFO

	blip = ANSIBLE_INFO['HOST']
	bluser = ANSIBLE_INFO['USER']
	blpasswd = ANSIBLE_INFO['PASSWD']
	
	tmphost_file = hostfile #存放ansibe的host临时文件
	tmpconfig_file = configfile #中间件的相关信息描述

	remote_hostfile = os.path.join('/tmp',tmphost_file)
	remote_configfile = os.path.join('/tmp',tmpconfig_file)

	port = 22
	t = paramiko.Transport((blip,port))
	t.connect(username=bluser,password=blpasswd)
	sftp = paramiko.SFTPClient.from_transport(t)
	try:
		sftp.put(tmpconfig_file,remote_configfile,confirm=True)
		sftp.put(tmphost_file,remote_hostfile,confirm=True)	#上传本地源文件到Ansible服务器
		# time.sleep(2)
		# loginfo.info('上传配置文件到Ansible服务器')	
	except Exception, e:
		raise e
	finally:
		sftp.close()
 

	ssh = paramiko.SSHClient()
	ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
	try:
		# time.sleep(3)
		# loginfo.info('在Ansible服务上执行Playbooks')	
		ssh.connect(hostname = blip, username = bluser, password = blpasswd)
		stdin,stdout,stderr=ssh.exec_command('cd /app/ansible/deploy/%s;\cp %s /app/ansible/deploy/%s/%s;tar czvf %s.tar.gz %s' % (softname,remote_configfile,softname,softversion,softversion,softversion))
		
		if version_num:
			stdin,stdout,stderr=ssh.exec_command('cd /app/ansible/deploy/%s;ansible-playbook -i %s deploy_%s.yml --extra-vars "version=%s"' % (softname,remote_hostfile,softname,version_num))    
			loginfo.info(stdout.read())
		else:
			stdin,stdout,stderr=ssh.exec_command('cd /app/ansible/deploy/%s;ansible-playbook -i %s deploy_%s.yml' % (softname,remote_hostfile,softname))    
			loginfo.info(stdout.read()) 

	except Exception,e:
		raise e 
	finally:
		stdin,stdout,stderr=ssh.exec_command('rm -f %s %s ' % (remote_hostfile,remote_configfile))
		ssh.close()

def soft_version(tag):
	ANSIBLE_INFO = settings.ANSIBLE_INFO
	host = ANSIBLE_INFO['HOST']
	user = ANSIBLE_INFO['USER']
	passwd = ANSIBLE_INFO['PASSWD']

	ssh = paramiko.SSHClient()
	ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
	try:
		ssh.connect(hostname = host, username = user, password = passwd)
		stdin,stdout,stderr=ssh.exec_command('''ls -l /app/ansible/deploy/%s | grep "^d" | awk "{print \$NF}"''' % tag)
		data = stdout.read() 
	except Exception,e:
		raise e 
	finally:
		ssh.close()

	return data

# 清除临时文件
def clear_tmpfile(file_list):
	for tmp_file in file_list:
		if os.path.exists(tmp_file):
			os.remove(tmp_file)

if __name__ == '__main__':
	exec_install('192.168.137.2','root','wangdong','mongodb','/tmp/mongodb_host','/tmp/mongodb_config')


