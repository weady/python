# -*- coding:utf-8 -*-
# coding=utf-8
__author__ = '001163'


from django import forms
# from autodeploy.models import Publisher, App_deploy_batch

# class PublisherForm(forms.Form):
#     name = forms.CharField(label="名称", max_length=10, error_messages={'required': u'这个项必须填写'})
#     address = forms.CharField(label="地址", max_length=100, error_messages={'required': u'这个项必须填写'})
#     city = forms.CharField(label="城市", error_messages={'required': u'这个项必须填写'})
#     state_province = forms.CharField(label="省份", error_messages={'required': u'这个项必须填写'})
#     country = forms.CharField(label="国家", error_messages={'required': u'这个项必须填写'})
#     website = forms.URLField(label="网址", error_messages={'required': u'这个项必须填写'})
#
#     # name = forms.CharField(label="名称")
#     # address = forms.CharField(label="地址")
#     # city = forms.CharField(label="城市")
#     # state_province = forms.CharField(label="省份")
#     # country = forms.CharField(label="国家")
#     # website = forms.URLField(label="网址")


# class PublisherForm(forms.ModelForm):
#
#     class Meta:
#         model = Publisher
#         exclude = ("id",)


class AddDeployForm(forms.Form):
    # batch_no = forms.CharField(widget=forms.TextInput(attrs={'class':'col-xs-10 col-sm-8','placeholder':'更新批次', 'id':'form-field-9'})) #更新批次
    # batch_no = forms.CharField()
    subject = forms.CharField(widget=forms.TextInput(attrs={'class':'col-xs-10 col-sm-6', 'placeholder':'主题', 'id':'form-field-9'}))    #更新主题
    auditor = forms.CharField(widget=forms.TextInput(attrs={'class':'col-xs-10 col-sm-6', 'placeholder':'审批人', 'id':'form-field-9'}))
    content = forms.CharField(widget=forms.Textarea(attrs={'class':'autosize-transition form-control', 'style':'overflow: hidden; word-wrap: break-word; resize: horizontal; height: 200px;'}))                      #更新项目
    desc = forms.CharField(widget=forms.Textarea(attrs={'class':'autosize-transition form-control', 'style':'overflow: hidden; word-wrap: break-word; resize: horizontal; height: 100px;'}))
    # bathch_log = forms.CharField(max_length=50, verbose_name="更新日志")                     #更新日志
    # # create_time = fo.DateTimeField(verbose_name="创建时间", auto_now_add=True, null=True) #创建时间
    # create_time = forms.DateTimeField(verbose_name="创建时间", auto_now_add=True) #创建时间
    # audit_time = forms.DateTimeField(verbose_name="审批时间", auto_now=True)      #审批时间
    # finish_time = forms.DateTimeField(verbose_name="完成时间", auto_now=True)     #完成时间
    # launcher = forms.CharField(max_length=10, verbose_name="发起人")                         #发起人
    # auditor = forms.CharField(max_length=10, verbose_name="审批人")                          #审批人
    # operator = forms.CharField(max_length=10, verbose_name="操作人")                         #操作人
    # is_undo = forms.IntegerField(default=0)                                                 #是否回滚过，0没有，1有


    #
    # class Meta:
    #     model = App_deploy_batch
    #     exclude = ("id",)


class SearchSiteForm(forms.Form):
    s_content = forms.CharField(widget=forms.TextInput(attrs={'class':'nav-search-input', 'placeholder':'搜索批次', 'id':'nav-search-input'}))



class SearchLogForm(forms.Form):
    s_content = forms.CharField(widget=forms.TextInput(attrs={'class':'nav-search-input', 'placeholder':'搜索用户', 'id':'nav-search-input'}))