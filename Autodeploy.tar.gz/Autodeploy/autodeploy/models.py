# -*- coding:utf-8 -*-
#!/usr/bin/env python
__author__ = '001163'


from django.db import models

# class Publisher(models.Model):
#     name = models.CharField(max_length=100, verbose_name="名称")
#     address = models.CharField(max_length=100, verbose_name="地址")
#     city = models.CharField(max_length=10, verbose_name="城市")
#     state_province = models.CharField(max_length=10, verbose_name="省份")
#     country = models.CharField(max_length=10, verbose_name="国家")
#     website = models.URLField(verbose_name="网址")
#
#
#     class Meta:
#         verbose_name = "出版商"
#         verbose_name_plural = verbose_name
#


# class Env_desc(models.Model):
#     # id = models.AutoField(primary_key=True)                                                #主键id，递增
#     env_name = models.CharField(max_length=30, verbose_name="环境名称")                       #环境名称




#应用更新批次表
class App_deploy_batch(models.Model):
    id = models.AutoField(primary_key=True)                                                  #主键id，递增
    batch_no = models.CharField(max_length=30, verbose_name="更新批次号")                     #更新批次
    subject = models.CharField(max_length=100, verbose_name="更新主题")                       #更新主题
    auditor = models.CharField(max_length=10, verbose_name="审批人")                          #审批人
    content = models.CharField(max_length=1000, verbose_name="更新项目")                      #更新项目
    create_time = models.DateTimeField(verbose_name="创建时间", auto_now_add=True)            #创建时间
    audit_time = models.DateTimeField(verbose_name="审批时间", null=True, blank=True, default=None)                 #审批时间
    finish_time = models.DateTimeField(verbose_name="完成时间", null=True, blank=True, default=None)                #完成时间
    launcher = models.CharField(max_length=10, verbose_name="发起人")                         #发起人
    auditor = models.CharField(max_length=10, verbose_name="审批人")                          #审批人
    operator = models.CharField(max_length=10, verbose_name="操作人")                         #操作人
    status = models.IntegerField(default=0, verbose_name="更新状态")                           #状态，0 审批中，1 更新中，2 更新成功，3，更新异常
    is_undo = models.IntegerField(default=0, verbose_name="回滚与否")                          #是否回滚过，0没有，1有
    plan = models.IntegerField(default=0, verbose_name="更新计划")                             #更新安全，0，手动更新，1自动更新(审批后即进行)
    env = models.IntegerField(default=0, verbose_name="更新环境")                              #环境：0 测试环境，1 生产环境
    desc = models.CharField(max_length=2000, verbose_name="更新说明")                          #更新说明
    message_type = models.IntegerField(default=0, verbose_name="通知方式")     #通知方式，0 不通知，1 邮件通知，2 短信通知，3 邮件短信均通知
    type = models.IntegerField(default=0, verbose_name="更新方式")             #更新方式，0、全量更新 1、增量更新, 2、全量回滚, 3、增量回滚
    message_cc = models.CharField(max_length=200, verbose_name="通知抄送人")                 #邮件通知抄送人
    batch_log = models.CharField(max_length=30, verbose_name="批次日志") #批次号日志文件
    # app_id = db.Column(db.Integer, db.ForeignKey('apps.id'), nullable=False)  #应用id，关联apps表id字段
    # app_name = db.Column(db.String(40), nullable=False)  #应用名，如aicai_webclient

    def __str__(self):
        return self.batch_no

    class Meta:
        db_table = "app_deploy_batch"
        verbose_name = '更新批次表'
        verbose_name_plural = verbose_name
        ordering = ['-id']


#用户行为日志表
class User_ac_log(models.Model):
    account = models.CharField(max_length=10, verbose_name="操作人")                         #操作人
    ip = models.CharField(max_length=30, verbose_name="操作IP")                             #操作IP
    create_time = models.DateTimeField(verbose_name="创建时间", null=True, blank=True, default=None)           #创建时间
    action = models.CharField(max_length=30, verbose_name="动作")                            #动作
    result = models.CharField(max_length=50, verbose_name="操作内容")                        #操作内容

    def __str__(self):
        return self.account

    class Meta:
        db_table = "user_ac_log"
        verbose_name = '行为日志表'
        verbose_name_plural = verbose_name
        ordering = ['id']


class Permission(models.Model):
    name = models.CharField("权限名称", max_length=64)
    url = models.CharField('URL名称', max_length=255)
    chioces = ((1, 'GET'), (2, 'POST'))
    per_method = models.SmallIntegerField('请求方法', choices=chioces, default=1)
    argument_list = models.CharField('参数列表', max_length=255, help_text='多个参数之间用英文半角逗号隔开', blank=True, null=True)
    describe = models.CharField('描述', max_length=255)

    def __str__(self):
        return self.name

    class Meta:
        verbose_name = '权限表'
        verbose_name_plural = verbose_name

        # 权限信息，这里定义的权限的名字，后面是描述信息，描述信息是在django admin中显示权限用的
        permissions = (
            ('approve_success', '审核通过'),
            ('rollback', '回滚权限'),
            ('approve_notgo', '审核驳回'),
        )




