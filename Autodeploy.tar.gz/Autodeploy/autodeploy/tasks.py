# -*- coding:utf-8 -*-
#!/usr/bin/env python
__author__ = '001163'
import time, os, sys

from mysite.celery import app

#测试异步任务
@app.task
def hello_world(x, y):
    print "任务开始"
    # time.sleep(1)
    return x + y



#更新异步任务
@app.task
def doautodeploy(batch_no):
    ''' run  dotask '''

    batch_log=batch_no.split('-')[2]
    print batch_log

    #time.sleep(0.5)

    # print "---------------------0000"*10
    #data = os.popen('/home/appdeploy/AutoDeploy/scripts/deploy_app.sh %s' % batch_log).read()
    data = os.popen('/app/deploy_apps/auto/auto_deploy_v2.0.sh %s' % batch_log).read()
    print "---"*10
    # print "okdada%s"%batch_no
    print "调用发布脚本成功"
    print batch_log
    print "---"*10
    print data
    print "---"*10


#回滚异步任务
@app.task
def doautorollback(batch_no):
    ''' run  dotask '''

    batch_log=batch_no.split('-')[2]
    print batch_log

    print "---------------------0000"*10
    # time.sleep(10)
    #data = os.popen('/home/appdeploy/AutoDeploy/scripts/deploy_roll.sh %s' % batch_log).read()
    data = os.popen('/app/deploy_apps/auto/auto_rollback_v2.0.sh %s' % batch_log).read()
    print "调用回滚脚本成功"
    print data
    print "---------------------0000"*10
