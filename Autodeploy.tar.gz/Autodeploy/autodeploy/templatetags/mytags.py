# -*- coding:utf-8 -*-
#!/usr/bin/env python
__author__ = '001163'


from django import template
from mysite import settings


register = template.Library()


@register.filter()
def env_deal(value):
    "Customize tag filters"

    if len(str(value)) >= 1 :
        new_value = int(value)
        result = settings.DEPLOY_ENV[new_value]
        return result

    else:
        pass


@register.filter()
def env_split(value):
    new_value = value.split()
    print "*初始值"
    print value
    print "新值*10"

    print new_value
    print type(new_value)
    print "*"*10

    return new_value


@register.filter()
def env_strip(value):
    new_value = value.strip(',')
    print "*初始值"
    print value
    print "新值*10"

    print new_value
    print type(new_value)
    print "*"*10

    return new_value
