# -*- coding: utf-8 -*-
#!/usr/bin/env python
__author__ = '001163'

import sys,os
reload(sys)

sys.setdefaultencoding('utf-8')


from django.shortcuts import render_to_response, redirect, render
from django.http import HttpResponse, HttpResponseRedirect, Http404
from django.template import RequestContext
from django.contrib.auth.decorators import login_required
from django.contrib import auth
from datetime import datetime, date, timedelta
from django.contrib.auth.models import User
from django.db.models import Q
# from models import Publisher
from autodeploy.forms import  AddDeployForm, SearchSiteForm, SearchLogForm
from datetime import datetime, date, timedelta
import models
from django.forms.models import model_to_dict

from django.conf import settings

from .tasks import hello_world, doautodeploy, doautorollback
import json

from django.views.decorators.clickjacking import xframe_options_exempt

from  django.core.paginator import Paginator, InvalidPage, EmptyPage, PageNotAnInteger
from mysite.permission import check_permission

from django.views.decorators.csrf import csrf_protect, csrf_exempt, ensure_csrf_cookie

# 引入部署中间件模块
import appdeploy
import os,time

#分页优化函数
class JuncheePaginator(Paginator):
    def __init__(self, object_list, per_page, range_num=2, orphans=0, allow_empty_first_page=True):
        Paginator.__init__(self, object_list, per_page, orphans, allow_empty_first_page)
        self.range_num = range_num

    def page(self, number):
        self.page_num = number
        return super(JuncheePaginator, self).page(number)

    def _page_range_ext(self):
        num_count = 2 * self.range_num + 1
        if self.num_pages <= num_count:
            return range(1, self.num_pages + 1)
        num_list = []
        num_list.append(self.page_num)
        for i in range(1, self.range_num + 1):
            if self.page_num - i <= 0:
                num_list.append(num_count + self.page_num - i)
            else:
                num_list.append(self.page_num - i)

            if self.page_num + i <= self.num_pages:
                num_list.append(self.page_num + i)
            else:
                num_list.append(self.page_num + i - num_count)
        num_list.sort()
        return num_list

    page_range_ext = property(_page_range_ext)


#全局setting函数
def global_settings(request):
    # print type(settings.DEPLOY_ENV)
    return {"DEPLOY_STATUS": settings.DEPLOY_STATUS,
            "DEPLOY_ENV": settings.DEPLOY_ENV,
            "DEPLOY_TYPE": settings.DEPLOY_TYPE,
            "DEPLOY_PLAN": settings.DEPLOY_PLAN}

#获取用户登录真实IP
def get_client_ip(request):
    try:
        real_ip = request.META['HTTP_X_FORWARDED_FOR']
        regip = real_ip.split(",")[0]
    except:
        try:
            regip = request.META['REMOTE_ADDR']
        except:
            regip = ""
    print "用户真实IP%s  " %regip
    return regip

def session_asset(request):
    user = request.session.get("username", "")
    if user:
        userData = User.objects.get(username=user)
        all_dict = {
            "username": userData.username,
            "password": userData.password,
            "last_name": userData.last_name,
            "telephone": userData.first_name,
            "email": userData.email,
            "is_active": userData.is_active
            # "last_login": userData.last_login
        }
        request.session["UserData"] = all_dict

#强制设置防跨站请求
@csrf_exempt
def login(request):
    if request.method == 'GET':
        print "ok"
        # return "ok"
        return render(request, 'user/login.html')

    if request.method == 'POST':

        #获取用户登录真实IP地址
        user_real_ip=get_client_ip(request)
        print "----"
        print user_real_ip
        print "----"

        print '登录用户名:', request.POST.get('user'), '密码:', request.POST.get('password')
        username = request.POST.get('user')
        password = request.POST.get('password')
        user = auth.authenticate(username=username, password=password)

        if user is not None:
            auth.login(request, user)
            request.session["username"] = username
            # print request.session["username"]

            session_asset(request)
            userinfo = request.session["UserData"]["last_name"] + ' - %s' % request.session["UserData"]["username"]
            username = request.session["UserData"]["last_name"]

            # 保存用户操作记录
            user_ac_record = models.User_ac_log(account=username,
                                                ip=user_real_ip,
                                                action='login',
                                                create_time=datetime.now(),
                                                result='True')
            # 写入数据库
            user_ac_record.save()

            return HttpResponseRedirect("deploy")
        else:

            error = "用户名或密码错误，请重新输入"
            return render(request, 'user/login.html', locals())

#退出登录,并自动重定向至登录页面
def logout(request):

    # #获取登录用户信息
    # session_asset(request)
    # userinfo = request.session["UserData"]["last_name"] + ' - %s' % request.session["UserData"]["username"]
    # username = request.session["UserData"]["last_name"]
    #
    # print username
    #
    # # 保存用户操作记录
    # user_ac_record = models.User_ac_log(account=username,
    #                                     ip="10.118.166.110",
    #                                     action='logout',
    #                                     create_time=datetime.now(),
    #                                     result='logout')
    # # 写入数据库
    # user_ac_record.save()

    auth.logout(request)
    return HttpResponseRedirect("login")


@login_required()
def index(request):
    # return HttpResponse("登录成功！")

    # count_dic = {}
    #
    # #生产环境更新数量
    # pro_count = models.App_deploy_batch.objects.filter(env='2').count()
    # print pro_count
    #
    # #灰度环境更新数量
    # grey_count = models.App_deploy_batch.objects.filter(env='1').count()
    # print grey_count
    #
    # #用户总数
    # user_count = User.objects.count()
    # print user_count
    #
    # #总更新次数
    # update_count = models.App_deploy_batch.objects.count()
    # print update_count
    #
    # #字典赋值
    # count_dic['pro_count'] = pro_count
    # count_dic['grey_count'] = grey_count
    # count_dic['user_count'] = user_count
    # count_dic['update_count'] = update_count

    #获取登录用户信息
    session_asset(request)
    userinfo = request.session["UserData"]["last_name"]+' - %s' % request.session["UserData"]["username"]
    lastname = request.session["UserData"]["last_name"]
    username = request.session["UserData"]["username"]
    # last_login = request.session["UserData"]["last_login"]+'%s' % request.session["UserData"]["last_login"]
    # print username
    #
    # # 最近10次更新
    # update_list = models.App_deploy_batch.objects.all()[:10]
    #
    # #最近10次回滚
    # app_undo_top10 = models.App_deploy_batch.objects.filter(is_undo=1).all()[:10]
    # print app_undo_top10
    #
    # #发起人更新次数Top10
    # app_launcher_top10 = models.App_deploy_batch.objects.filter(launcher=lastname).all()[:10]
    # # app_launcher_top10 = models.App_deploy_batch.objects.all()[:10]
    #
    # print '----------'
    # print lastname
    # print app_launcher_top10
    # print '----------'

    #获取最近七天日期
    today = date.today()
    senven_day_list = []

    for i in range(0, 31):
        d2 = today + timedelta(-i)
        senven_day_list.append(d2.strftime("%m/%d"))

    # #最近一个月生产环境更新次数
    # full_update_list = [a.date for a in models.App_deploy_batch.objects.get(
    #     models.App_deploy_batch.create_time)]

    # full_update_list = [(a.date, a.count) for a in models.App_deploy_batch.objects.filter(
    #     settings.DATE_FORMAT(models.App_deploy_batch.create_time, '%m/%d').label('date'),
    #     func.count(models.App_deploy_batch.id).label('count')).filter(
    #     models.App_deploy_batch.env.in_((1, 2))).group_by(
    #     func.date_format(models.App_deploy_batch.create_time, '%m/%d'))]

    # print full_update_list

    return render(request, "deploy/index.html", locals())
    # return render_to_response("base/base.html", locals())

# def global_settings(request):
#      return {"DEPLOY_ENV": settings.DEPLOY_ENV, "DEPLOY_PLAN": settings.DEPLOY_PLAN}
#
#
# @register.simple_tag

@login_required()
@csrf_exempt
def deploy(request):

    #获取登录用户信息
    session_asset(request)
    userinfo = request.session["UserData"]["last_name"]+' - %s' % request.session["UserData"]["username"]
    username = request.session["UserData"]["last_name"]

    # 定义一个搜索的表单
    form = SearchSiteForm()

    DEPLOY_ENV=settings.DEPLOY_ENV

    # print type(DEPLOY_ENV)

    #更新批次列表
    object_list = models.App_deploy_batch.objects.all()[:20]

    # paginator = Paginator(object_list, 10)
    item = request.POST.get('s_content')

    if request.method == "POST" and item:
        # filter_string = ' like "%' + request.POST["s_content"] + '%"'

        # 打印输入的搜索的内容
        print item

        object_list = models.App_deploy_batch.objects.filter(Q(batch_no__icontains=item)| Q(content__contains=item)| Q(launcher__contains=item))

        return render(request, "deploy/deploy.html", locals())

    else:
        # object_list = models.App_deploy_batch.objects.all()
        object_list = models.App_deploy_batch.objects.filter(env="2")


    return render(request, "deploy/deploy.html", locals())

@login_required()
def deploygo(request, batch_no):

    object_list = models.App_deploy_batch.objects.get(batch_no=batch_no)

    #和该批次有关的行为
    ac_list = models.User_ac_log.objects.filter(result=batch_no).all()

    #和该批次有关的行为
    # ac_lists = models.User_ac_log.objects.filter(result=batch_no)

    print "测试"
    # print object_list
    # print type(object_list)
    print type(ac_list)
    # ac_list = ac_lists.objects.all()
    for i in ac_list:
        print i.account
        print i.ip
    print "测试"


    DEPLOY_ENV=settings.DEPLOY_ENV
    MESSAGE_TYPE=settings.MESSAGE_TYPE
    DEPLOY_PLAN=settings.DEPLOY_PLAN
    DEPLOY_TYPE=settings.DEPLOY_TYPE
    USER_ACTION_CONVERT=settings.USER_ACTION_CONVERT

    #获取登录用户信息
    session_asset(request)
    userinfo = request.session["UserData"]["last_name"]+' - %s' % request.session["UserData"]["username"]
    username = request.session["UserData"]["last_name"]

    #数据库查询对象转换为字典
    object = model_to_dict(object_list)

    # ac_list = model_to_dict(ac_lists)

    # is_approve = True if username.has_perm('models..add') else False

    # print ac_list
    # print object.get('env')

    return render(request, "deploy/deploygo.html", locals())

# @login_required()
def adddeploy(request):

    # 获取用户登录真实IP地址
    user_real_ip = get_client_ip(request)

    session_asset(request)
    userinfo = request.session["UserData"]["last_name"]+' - %s' % request.session["UserData"]["username"]
    username = request.session["UserData"]["last_name"]

    #POST请求
    if request.method == "POST":

        # 构建一个发起更新的表单
        form = AddDeployForm(request.POST)

        # 批次号前缀
        batch_no_prefix = "UOA-"

        #以日期为时间戳，生成日志文件
        batch_log = datetime.now().strftime('%Y%m%d%H%M')

        #生成batch_no,strip去掉首尾空格
        batch_no = batch_no_prefix + "fcbox" + "-" + batch_log

        #更新批次状态为审批中
        status = 0

        print batch_no
        print batch_log

        # 将更新内容写入文件
        # file_list = "/app/deploy_apps/deploy_list.txt"
        file_list = "/tmp/deploy_list.txt"


        #获取form表单中写入的更新项目列表
        content=request.POST["content"]

        print request.POST["subject"]
        # print AddDeployForm.cleaned_data[""]
        # print DEPLOY_ENV[0]
        # print DEPLOY_PLAN[0]
        print "更新想"
        print username
        # print request.POST["content"]
        content=request.POST["content"]
        print content
        print "更新想"


        if len(content):
            with open(file_list, 'wb') as file:
                # file.write(''.join(content.replace("$", "").replace("\r", "").split(' ')))
                file.write(''.join(content.replace("\r", "").split(' ')))


        # 通过表单构建数据库插入记录
        record = models.App_deploy_batch(batch_no=batch_no,
                                         subject=request.POST["subject"],
                                         status=status,
                                         type=0,     #0 '全量更新', '1 增量更新', '2 全量回滚', '3 增量回滚')
                                         plan=0,     #0，手动更新， 1，自动更新(审批后即进行)
                                         env=2,      #环境：0 测试环境，1 生产环境
                                         launcher=username,
                                         # auditor=request.POST["auditor"],
                                         auditor='李惠广',
                                         content=content,
                                         batch_log=batch_log,
                                         message_type=1,  #通知方式，0 不通知，1 邮件通知，2 短信通知，3 邮件短信均通知
                                         desc=request.POST["desc"],
                                         )

        # print record

        #保存数据
        record.save()

        print "数据库保存状态"
        print record.save
        # print record.save()
        print "数据库保存状态"

        #写入数据库
        if record.save:

            print "保存日志记录"

            # 保存用户操作记录
            user_ac_record = models.User_ac_log(account=username,
                                                ip=user_real_ip,
                                                action='adddeploy',
                                                create_time=datetime.now(),
                                                result=batch_no)
            # 写入数据库
            user_ac_record.save()

            print "保存日志记录"

        #重定向回发起更新页面
        return HttpResponseRedirect('deploy')


    # #GET请求
    else:
        #获得应用的所有属性
        form = AddDeployForm()
        # return HttpResponse("更新")

        return render(request, "deploy/adddeploy.html", locals())




#审批更新通过
@login_required()
@check_permission
def approve_success(request, batch_no):

    # 获取用户登录真实IP地址
    user_real_ip = get_client_ip(request)

    session_asset(request)
    userinfo = request.session["UserData"]["last_name"]+' - %s' % request.session["UserData"]["username"]
    username = request.session["UserData"]["last_name"]


    object = models.App_deploy_batch.objects.get(batch_no=batch_no)

    #和该批次有关的行为
    ac_list = models.User_ac_log.objects.filter(result=batch_no).all()

    #修改更新批次状态为2，待更新
    object.status = 2

    # object.audit_time = datetime.now()
    print "审批时间"
    print datetime.now
    object.audit_time = datetime.now()
    print "审批时间"

    DEPLOY_ENV=settings.DEPLOY_ENV
    MESSAGE_TYPE=settings.MESSAGE_TYPE
    DEPLOY_PLAN=settings.DEPLOY_PLAN
    DEPLOY_TYPE=settings.DEPLOY_TYPE
    USER_ACTION_CONVERT=settings.USER_ACTION_CONVERT

    #保存数据库
    object.save()


    if object.save:
        print "审批通过"

        print "保存日志记录"

        # 保存用户操作记录
        user_ac_record = models.User_ac_log(account=username,
                                            ip=user_real_ip,
                                            action='approve_success',
                                            create_time=datetime.now(),
                                            result=batch_no)
        # 写入数据库
        user_ac_record.save()

        print "保存审批通过日志记录"

    # return HttpResponseRedirect('/deploygo', batch_no=batch_no)
    return render(request, "deploy/deploygo.html", locals())


#审批更新驳回
@login_required()
@check_permission
def approve_notgo(request, batch_no):

    # 获取用户登录真实IP地址
    user_real_ip = get_client_ip(request)

    session_asset(request)
    userinfo = request.session["UserData"]["last_name"] + ' - %s' % request.session["UserData"]["username"]
    username = request.session["UserData"]["last_name"]

    # 和该批次有关的行为
    ac_list = models.User_ac_log.objects.filter(result=batch_no).all()

    object = models.App_deploy_batch.objects.get(batch_no=batch_no)

    #修改更新批次状态为1，审核驳回
    object.status = 1

    DEPLOY_ENV=settings.DEPLOY_ENV
    MESSAGE_TYPE=settings.MESSAGE_TYPE
    DEPLOY_PLAN=settings.DEPLOY_PLAN
    DEPLOY_TYPE=settings.DEPLOY_TYPE
    USER_ACTION_CONVERT = settings.USER_ACTION_CONVERT

    object.finish_time = datetime.now()

    #保存数据库
    object.save()

    if object.save:
        print "审核驳回"

        # 保存用户操作记录
        user_ac_record = models.User_ac_log(account=username,
                                            ip=user_real_ip,
                                            action='approve_notgo',
                                            create_time=datetime.now(),
                                            result=batch_no)
        # 写入数据库
        user_ac_record.save()


    return render(request, "deploy/deploygo.html", locals())

# #编辑更新
# def editdeploy(request,batch_id):
#
#     object = models.App_deploy_batch.objects.get(id=batch_id)


@login_required()
def notgo(request, batch_no):

    # 获取用户登录真实IP地址
    user_real_ip = get_client_ip(request)

    session_asset(request)
    userinfo = request.session["UserData"]["last_name"] + ' - %s' % request.session["UserData"]["username"]
    username = request.session["UserData"]["last_name"]

    # 和该批次有关的行为
    ac_list = models.User_ac_log.objects.filter(result=batch_no).all()

    object = models.App_deploy_batch.objects.get(batch_no=batch_no)

    #修改更新批次状态为6，取消更新
    object.status = 6
    object.finish_time = datetime.now()


    DEPLOY_ENV=settings.DEPLOY_ENV
    MESSAGE_TYPE=settings.MESSAGE_TYPE
    DEPLOY_PLAN=settings.DEPLOY_PLAN
    DEPLOY_TYPE=settings.DEPLOY_TYPE
    USER_ACTION_CONVERT=settings.USER_ACTION_CONVERT

    #保存数据库
    object.save()

    if object.save:
        print "取消更新"

        # 保存用户操作记录
        user_ac_record = models.User_ac_log(account=username,
                                            ip=user_real_ip,
                                            action='notgo',
                                            create_time=datetime.now(),
                                            result=batch_no)
        # 写入数据库
        user_ac_record.save()

    return render(request, "deploy/deploygo.html", locals())



#执行更新
@login_required()
def dodeploy(request, batch_no):
    # 获取用户登录真实IP地址
    user_real_ip = get_client_ip(request)

    session_asset(request)
    userinfo = request.session["UserData"]["last_name"]+' - %s' % request.session["UserData"]["username"]
    username = request.session["UserData"]["last_name"]

    #和该批次有关的行为
    ac_list = models.User_ac_log.objects.filter(result=batch_no).all()

    object = models.App_deploy_batch.objects.get(batch_no=batch_no)



    # 定义一个搜索的表单
    form = SearchSiteForm()

    #如果更新批次状态为更新中,则直接跳转，避免重复更新操作
    # if object.status >= 3:
    #     print "已经执行更新"
    #     return HttpResponseRedirect('deploygo', batch_no=batch_no)


    DEPLOY_ENV=settings.DEPLOY_ENV
    MESSAGE_TYPE=settings.MESSAGE_TYPE
    DEPLOY_PLAN=settings.DEPLOY_PLAN
    DEPLOY_TYPE=settings.DEPLOY_TYPE
    USER_ACTION_CONVERT=settings.USER_ACTION_CONVERT


    #修改更新批次状态为更新中
    object.status = 3

    #获取并保存操作人
    object.operator = username



    #执行更新操作
    print "--------执行了"*10
    doautodeploy.delay(batch_no)   #异步执行更新操作
    # doautodeploy(batch_no)         #同步执行更新操作
    print "执行完了"

    #保存数据库
    object.save()

    if object.save:
        # 保存用户操作记录
        user_ac_record = models.User_ac_log(account=username,
                                            ip=user_real_ip,
                                            action='dodeploy',
                                            create_time=datetime.now(),
                                            result=batch_no)
        # 写入数据库
        user_ac_record.save()

    # if object.save():
    #     print "更新状态为更新中"

    # print "修改更新状态为更新中"

    # return HttpResponse("执行更新")
    # return HttpResponseRedirect('/deploy')

    return render(request, "deploy/deploygo.html", locals())
    # return render(request, "deploy/deploy.html", locals())


#灰度发布
@login_required()
def deploy_grey(request):

    #获取登录用户信息
    session_asset(request)
    userinfo = request.session["UserData"]["last_name"]+' - %s' % request.session["UserData"]["username"]
    username = request.session["UserData"]["last_name"]

    # 定义一个搜索的表单
    form = SearchSiteForm()

    DEPLOY_ENV=settings.DEPLOY_ENV

    # print type(DEPLOY_ENV)

    #更新批次列表
    object_list = models.App_deploy_batch.objects.all()[:20]

    # paginator = Paginator(object_list, 10)
    item = request.POST.get('s_content')

    if request.method == "POST" and item:
        # filter_string = ' like "%' + request.POST["s_content"] + '%"'

        # 打印输入的搜索的内容
        print item
        object_list = models.App_deploy_batch.objects.filter(Q(batch_no__icontains=item)| Q(content__contains=item)| Q(launcher__contains=item))
        return render(request, "deploy/deploy_grey.html", locals())

    else:
        # object_list = models.App_deploy_batch.objects.all()
        object_list = models.App_deploy_batch.objects.filter(env="1")

        return render(request, "deploy/deploy_grey.html", locals())


#生产环境一键回滚
@login_required()
@check_permission
def rollback(request, batch_no):

    # 获取用户登录真实IP地址
    user_real_ip = get_client_ip(request)

    session_asset(request)
    userinfo = request.session["UserData"]["last_name"]+' - %s' % request.session["UserData"]["username"]
    username = request.session["UserData"]["last_name"]

    object = models.App_deploy_batch.objects.get(batch_no=batch_no)

    #和该批次有关的行为
    ac_list = models.User_ac_log.objects.filter(result=batch_no).all()

    DEPLOY_ENV=settings.DEPLOY_ENV
    MESSAGE_TYPE=settings.MESSAGE_TYPE
    DEPLOY_PLAN=settings.DEPLOY_PLAN
    DEPLOY_TYPE=settings.DEPLOY_TYPE
    USER_ACTION_CONVERT=settings.USER_ACTION_CONVERT


    # # 定义一个搜索的表单
    # form = SearchSiteForm()


    #如果已经回滚过，则直接返回页面，不进行回滚操作，避免重复回滚
    if object.is_undo == 1:
        print "已经回滚过"
        # return HttpResponseRedirect('deploy')
        # return render(request, "deploy/deploygo.html", locals())
        return render(request, "deploy/deploy.html", locals())

    #回滚状态直接到更新中
    rollback_status = 3


    #如果更新是整站(0)，则type为整站回滚(2)
    if object.type == 0:
        rollback_type = 2


    #回滚批次号基于更新批次号，替换大写字母U(更新)为R(回滚)
    rollback_batch_no = object.batch_no.replace('U', 'R')


    # 通过表单构建数据库插入记录
    record = models.App_deploy_batch(batch_no=rollback_batch_no,
                                     subject=object.subject + '回滚',
                                     status=rollback_status,
                                     type=rollback_type,
                                     plan=0,  # 0，手动更新， 1，自动更新(审批后即进行)
                                     env=2,  # '测试环境', '灰度环境', '生产环境'
                                     launcher=username,
                                     is_undo='1',
                                     auditor=object.auditor,
                                     # content=content,
                                     batch_log=object.batch_log,
                                     message_type=1,  # 通知方式，0 不通知，1 邮件通知，2 短信通知，3 邮件短信均通知
                                     desc=object.desc,
                                     )

    #保存数据
    record.save()

    if record.save:

        # 执行更新操作
        print "--------执行了" * 10
        doautorollback.delay(batch_no)  # 异步执行更新操作
        # doautodeploy(batch_no)         #同步执行更新操作
        print "执行完了"

        # 保存用户操作记录
        user_ac_record = models.User_ac_log(account=username,
                                            ip=user_real_ip,
                                            action='rollback',
                                            create_time=datetime.now(),
                                            result=rollback_batch_no)
        # 写入数据库
        user_ac_record.save()

        print "一键回滚"

        # 修改更新批次回滚标志置为1
        object.is_undo = 1
        print "将更新批次的回滚标志置为1"
        object.save()

        print "回滚完了"

    # return "一键回滚"

    # return render(request, "deploy/deploygo.html", locals())
    return HttpResponseRedirect('/deploy')


#灰度环境一键回滚
@login_required()
@check_permission
def grey_rollback(request, batch_no):

    # 获取用户登录真实IP地址
    user_real_ip = get_client_ip(request)

    session_asset(request)
    userinfo = request.session["UserData"]["last_name"]+' - %s' % request.session["UserData"]["username"]
    username = request.session["UserData"]["last_name"]

    object = models.App_deploy_batch.objects.get(batch_no=batch_no)

    #和该批次有关的行为
    ac_list = models.User_ac_log.objects.filter(result=batch_no).all()

    DEPLOY_ENV=settings.DEPLOY_ENV
    MESSAGE_TYPE=settings.MESSAGE_TYPE
    DEPLOY_PLAN=settings.DEPLOY_PLAN
    DEPLOY_TYPE=settings.DEPLOY_TYPE
    USER_ACTION_CONVERT=settings.USER_ACTION_CONVERT


    # # 定义一个搜索的表单
    # form = SearchSiteForm()


    #如果已经回滚过，则直接返回页面，不进行回滚操作，避免重复回滚
    if object.is_undo == 1:
        print "已经回滚过"
        # return HttpResponseRedirect('deploy')
        # return render(request, "deploy/deploygo.html", locals())
        return render(request, "deploy/deploy_grey.html", locals())

    #回滚状态直接到更新中
    rollback_status = 3


    #如果更新是整站(0)，则type为整站回滚(2)
    if object.type == 0:
        rollback_type = 2


    #回滚批次号基于更新批次号，替换大写字母U(更新)为R(回滚)
    rollback_batch_no = object.batch_no.replace('G', 'L')


    # 通过表单构建数据库插入记录
    record = models.App_deploy_batch(batch_no=rollback_batch_no,
                                     subject=object.subject + '回滚',
                                     status=rollback_status,
                                     type=rollback_type,
                                     plan=0,  # 0，手动更新， 1，自动更新(审批后即进行)
                                     env=1,  # 环境：0 测试环境，1 生产环境
                                     launcher=username,
                                     is_undo='1',
                                     auditor=object.auditor,
                                     # content=content,
                                     batch_log=object.batch_log,
                                     message_type=1,  # 通知方式，0 不通知，1 邮件通知，2 短信通知，3 邮件短信均通知
                                     desc=object.desc,
                                     )

    #保存数据
    record.save()

    if record.save:

        # 执行更新操作
        print "--------执行了" * 10
        doautorollback.delay(batch_no)  # 异步执行更新操作
        # doautodeploy(batch_no)         #同步执行更新操作
        print "执行完了"

        # 保存用户操作记录
        user_ac_record = models.User_ac_log(account=username,
                                            ip=user_real_ip,
                                            action='rollback',
                                            create_time=datetime.now(),
                                            result=rollback_batch_no)
        # 写入数据库
        user_ac_record.save()

        print "一键回滚"

        # 修改更新批次回滚标志置为1
        object.is_undo = 1
        print "将更新批次的回滚标志置为1"
        object.save()

        print "回滚完了"

    # return "一键回滚"

    # return render(request, "deploy/deploygo.html", locals())
    return HttpResponseRedirect('/deploy_grey')

#任务日志ajax读取接口
@login_required()
def batchlog(request):
    print "####"*5
    batch_no = request.GET.get('batch_no')
    print batch_no
    print "####"*5
    #日志文件目录
    batchlog = os.path.join(settings.BATCH_LOG_BASE_URL, batch_no + '.log')

    print "任务日志"
    print batchlog
    print "任务日志"


    with open(batchlog, 'r') as file:
        batchlog_data = file.read()

    batchlog_data = batchlog_data.replace('\n', '<br>').replace(' ', '&nbsp').replace('[' + batch_no + ']', '')

    return HttpResponse(batchlog_data)

#发起灰度环境更新操作
@login_required()
def adddeploy_grey(request):

    # 获取用户登录真实IP地址
    user_real_ip = get_client_ip(request)

    session_asset(request)
    userinfo = request.session["UserData"]["last_name"]+' - %s' % request.session["UserData"]["username"]
    username = request.session["UserData"]["last_name"]

    #POST请求
    if request.method == "POST":

        # 构建一个发起更新的表单
        form = AddDeployForm(request.POST)

        # 批次号前缀
        batch_no_prefix = "GOA-"

        #以日期为时间戳，生成日志文件
        batch_log = datetime.now().strftime('%Y%m%d%H%M')

        #生成batch_no,strip去掉首尾空格
        batch_no = batch_no_prefix + "fcbox" + "-" + batch_log

        #更新批次状态为审批中
        status = 0

        print batch_no
        print batch_log

        # 将更新内容写入文件
        # file_list = "/app/deploy_apps/deploy_list.txt"
        file_list = "/tmp/deploy_list.txt"


        #获取form表单中写入的更新项目列表
        content=request.POST["content"]

        print request.POST["subject"]
        # print AddDeployForm.cleaned_data[""]
        # print DEPLOY_ENV[0]
        # print DEPLOY_PLAN[0]
        print "更新项"
        print username
        # print request.POST["content"]
        content=request.POST["content"]
        print content
        print "更新项"


        if len(content):
            with open(file_list, 'wb') as file:
                # file.write(''.join(content.replace("$", "").replace("\r", "").split(' ')))
                file.write(''.join(content.replace("\r", "").split(' ')))


        # 通过表单构建数据库插入记录
        record = models.App_deploy_batch(batch_no=batch_no,
                                         subject=request.POST["subject"],
                                         status=status,
                                         type=0,     #0 '全量更新', '1 增量更新', '2 全量回滚', '3 增量回滚')
                                         plan=0,     #0，手动更新， 1，自动更新(审批后即进行)
                                         env=1,      #环境：0 测试环境，1 生产环境
                                         launcher=username,
                                         # auditor=request.POST["auditor"],
                                         auditor='李惠广',
                                         content=content,
                                         batch_log=batch_log,
                                         message_type=1,  #通知方式，0 不通知，1 邮件通知，2 短信通知，3 邮件短信均通知
                                         desc=request.POST["desc"],
                                         )

        # print record

        #保存数据
        record.save()

        print "数据库保存状态"
        print record.save
        # print record.save()
        print "数据库保存状态"

        #写入数据库
        if record.save:

            print "保存日志记录"

            # 保存用户操作记录
            user_ac_record = models.User_ac_log(account=username,
                                                ip=user_real_ip,
                                                action='adddeploy',
                                                create_time=datetime.now(),
                                                result=batch_no)
            # 写入数据库
            user_ac_record.save()

            print "保存日志记录"

        #重定向回发起更新页面
        return HttpResponseRedirect('deploy_grey')


    # #GET请求
    else:
        #获得应用的所有属性
        form = AddDeployForm()
        # return HttpResponse("更新")

        return render(request, "deploy/adddeploy_grey.html", locals())

#更新查询
@login_required()
def deploy_his(request):

    #获取登录用户信息
    session_asset(request)
    userinfo = request.session["UserData"]["last_name"]+' - %s' % request.session["UserData"]["username"]
    username = request.session["UserData"]["last_name"]

    print "更新查询"
    #定义一个搜索的表单
    form = SearchSiteForm()

    DEPLOY_ENV=settings.DEPLOY_ENV

    #更新批次列表
    object_list = models.App_deploy_batch.objects.all()
    paginator = JuncheePaginator(object_list, 10)

    item = request.POST.get('s_content')

    try:
        page = int(request.GET.get('page', 1))
        object_list = paginator.page(page)

        if request.method == "POST" and item:
            print item
            if item == '灰度环境':
                item=1
            elif item == '生产环境':
                item=2
            print item
            object_list = models.App_deploy_batch.objects.filter(Q(batch_no__icontains=item)| Q(content__contains=item)| Q(launcher__contains=item)| Q(env__contains=item))
            paginator = JuncheePaginator(object_list, 10)
            object_list = paginator.page(page)
            return render(request, "deploy/deployhis.html", locals())

    except (EmptyPage, InvalidPage, PageNotAnInteger):
        object_list = paginator.page(1)

    return render(request, "deploy/deployhis.html", locals())

# def add_publisher(request):
#     if request.method == "POST":
#         # #一、不使用Form的情况
#         # #一、如果为post提交，去接收用户提交过来的数据，纯源生的方法写的表单
#         # print "添加信息"
#         # print request.POST
#         # name = request.POST["name"]
#         # address = request.POST.get("address")
#         # city = request.POST.get("city")
#         # state_province = request.POST.get("state_province")
#         # country = request.POST.get("country")
#         # website = request.POST.get("website")
#         #
#         # Publisher.objects.create(
#         #     name=name,
#         #     address=address,
#         #     city=city,
#         #     state_province=state_province,
#         #     country=country,
#         #     website=website,
#         # )
#
#
#         # # 二、使用Django Form的情况
#         # publisher_form = PublisherForm(request.POST)
#         #
#         # if publisher_form.is_valid():   #验证表单数据是否合法
#         #     Publisher.objects.create(
#         #         name=publisher_form.cleaned_data["name"],
#         #         address=publisher_form.cleaned_data["address"],
#         #         city=publisher_form.cleaned_data["city"],
#         #         state_province=publisher_form.cleaned_data["state_province"],
#         #         country=publisher_form.cleaned_data["country"],
#         #         website=publisher_form.cleaned_data["website"],
#         #     )
#         #     return HttpResponse("添加数据成功")
#
#
#         #三、使用ModelForm
#         publisher_form = PublisherForm(request.POST)
#         if publisher_form.is_valid():
#             publisher_form.save()
#             return HttpResponse("添加数据成功")
#     else:
#         publisher_form = PublisherForm()
#     return render(request, "deploy/addpublisher.html", locals())


def task(request):
    hello_world.delay(1, 2)
    return HttpResponse("执行完毕")


#用户行为日志查询
@csrf_exempt
def ac_logs(request):

    #获取登录用户信息
    session_asset(request)
    userinfo = request.session["UserData"]["last_name"]+' - %s' % request.session["UserData"]["username"]
    username = request.session["UserData"]["username"]

    # 定义一个搜索的表单
    form = SearchLogForm()
    USER_ACTION_CONVERT=settings.USER_ACTION_CONVERT

    item = request.POST.get('s_content')

    total = models.User_ac_log.objects.count()

    #POST请求
    if request.method == "POST" and item:
    # if item:
        print item
        object_list1 = models.User_ac_log.objects.filter(Q(account__icontains=item)).order_by('-id')
        paginator = JuncheePaginator(object_list1, 10)
        page = int(request.GET.get('page', 1))
        object_list = paginator.page(page)

        return render(request, "user/ac_logs.html", locals())

    else:
        object_list = models.User_ac_log.objects.order_by('-id')
        paginator = JuncheePaginator(object_list, 10)

        try:
            # # 更新批次列表
            page = int(request.GET.get('page', 1))
            object_list = paginator.page(page)

        except (EmptyPage, InvalidPage, PageNotAnInteger):
            object_list = paginator.page(1)

        return render(request, "user/ac_logs.html", locals())


#接口：修改更新任务状态
# @app.route('/api/v1.0/batch_task/modify_status/<batch_no>', methods=['POST'])
# @xframe_options_exempt
@csrf_exempt
def modify_batch_task_status(request, batch_no):

    #获取接口传递的数据
    txt = json.loads(request.body)

    if not request.body or not 'status' in request.body:
        print "异常"
        raise Http404

    #查询任务并修改任务状态
    record = models.App_deploy_batch.objects.get(batch_no=batch_no)

    #获取接口传递的status的值
    status = txt['status']

    #修改更新任务的状态
    record.status = int(status)

    #修改更新任务的完成时间
    record.finish_time = datetime.now()

    #保存数据
    record.save()

    #change

    return HttpResponse(json.dumps({'batch_no': batch_no, 'status': record.status}), status=202)
    # return HttpResponse("ok")


def test(request):
    # return ok
    return render(request, 'user/login.html')



# 中间件部署
def deploysoft(request):
    # 获取用户登录真实IP地址
    user_real_ip = get_client_ip(request)

    session_asset(request)
    userinfo = request.session["UserData"]["last_name"]+' - %s' % request.session["UserData"]["username"]
    username = request.session["UserData"]["last_name"]

    return render_to_response('deploy/deploysoft.html',locals())

@csrf_exempt
def installsoft(request):
    if request.method == 'POST':
        softname = request.POST['softname']
        ip_list = request.POST['ips']
        config_file = request.POST['configure']
        logfile = request.POST['logfile']
        softversion = request.POST['ver']
    

        # 生成ansible的临时hosts文件
        tmp_hosts_file = os.path.join('/tmp','%s_host' % softname)
        with open(tmp_hosts_file,'w') as tmpfile:
            tmpfile.write('[tmp_%s]\n' % softname)
            for line in ip_list.split('|'):
                tmpfile.write('%s\n' % line.strip())

        # 生成对应中间件的配置文件
        tmp_config_file = os.path.join('/tmp','%s_info.txt' % softname)
        with open(tmp_config_file,'w') as tmpconfig:
            for config_line in config_file.split('\n'):
                tmpconfig.write('%s\n' % config_line.strip())

        # 日志文件
        tmplogfile = os.path.join('/tmp',logfile) + '.log'

        # exec_install函数传参格式:softname,hostfile,configfile,logfile,softversion
        try:
            appdeploy.exec_install(softname,tmp_hosts_file,tmp_config_file,tmplogfile,softversion)
        except Exception as e:
            raise e
        finally:
            appdeploy.clear_tmpfile([tmp_hosts_file,tmp_config_file])


        return HttpResponse('OK')

#ajax实现日志的定时刷新 logname:softinstall
@csrf_exempt
def flushlog(request):
    if request.method == 'POST':
        data = get_flush_log(request.POST['logfile'], request.POST['time_flag'])
        return HttpResponse(json.dumps(data))


#日志刷新
def get_flush_log(log_file, times):
    '''
    滚动日至处理函数,@log_file为前端传入到文件前缀,times为前端传初到时间格式 eg:2017-02-19 12:10:01
    '''
    data = []
    req_times = time.mktime(time.strptime(times , "%Y-%m-%d %H:%M:%S"))
    try:
        with open(os.path.join('/tmp', log_file)+'.log') as files:
            for logs in files:
                # tmp = time.mktime(time.strptime(re.split('\]|\[',logs)[1].strip(), "%Y-%m-%d %H:%M:%S"))
                # if req_times < tmp:
                data.append(logs)
    except Exception as e:
        data = []
    return data

#
@csrf_exempt
def getsoft_version(request):
    if request.method == 'POST':
        middleware_name = request.POST['tag']
        data = appdeploy.soft_version(middleware_name)
        result = data.split('\n')
        return HttpResponse(json.dumps(result))