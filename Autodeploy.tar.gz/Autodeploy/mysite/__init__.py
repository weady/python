# -*- coding:utf-8 -*-
#!/usr/bin/env python
__author__ = '001163'


import pymysql
pymysql.install_as_MySQLdb()