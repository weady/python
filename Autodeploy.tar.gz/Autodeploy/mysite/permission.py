# -*- coding: utf-8 -*-
#!/usr/bin/env python
__author__ = '001163'

from django.shortcuts import render
from django.http import HttpResponse
from django.shortcuts import render_to_response
from autodeploy import models
from django.db.models import Q
# 此方法可以将url地址转换成url的name
from django.core.urlresolvers import resolve
from django.contrib.auth.models import User

from django.http import JsonResponse


def method_map(var):
    if var == 'GET':
        var = '1'
    elif var == 'POST':
        var = '2'
    return var

def session_asset(request):
    user = request.session.get("username", "")
    if user:
        userData = User.objects.get(username=user)
        all_dict = {
            "username": userData.username,
            "password": userData.password,
            "last_name": userData.last_name,
            "telephone": userData.first_name,
            "email": userData.email,
            "is_active": userData.is_active
            # "last_login": userData.last_login
        }
        request.session["UserData"] = all_dict

def perm_check(request, *args, **kwargs):
    url_obj = resolve(request.path_info)
    # permission_name
    url_name = url_obj.url_name
    #
    # print "======"
    # print url_name
    # print "======"

    session_asset(request)
    userinfo = request.session["UserData"]["last_name"] + ' - %s' % request.session["UserData"]["username"]
    username = request.session["UserData"]["last_name"]

    print "装饰器用户名"
    print userinfo

    if url_name:
        # 获取请求方法，和请求参数
        url_method, url_args = request.method, request.GET
        url_method = method_map(url_method)
        print url_name, url_method
        # 操作数据库
        # get_perm = models.Permission.objects.filter(Q(name=url_name) and Q(per_method=url_method))
        get_perm = models.Permission.objects.filter(name=url_name, per_method=url_method)
        print "ok-ok"
        print get_perm
        print "ok-ok"

        if get_perm:
            for i in get_perm:
                perm_name = i.name
                perm_str = 'autodeploy.%s' % perm_name
                print perm_str
                print request.user
                print "-----"
                if request.user.has_perm(perm_str):
                    print('====》权限已匹配')
                    return True
                else:
                    print('---->权限没有匹配')
                    return False
        else:
            return False
    else:
        # 没有权限设置，默认不放过
        return False


# def check_permission(fun):
#     def wapper(request, *args, **kwargs):
#         if perm_check(request, *args, **kwargs):
#             perm = True
#             return fun(request, perm)
#         else:
#             perm = False
#             return fun(request, perm)
#     return wapper

def check_permission(fun):    #定义一个装饰器，在views中应用
    def wapper(request, *args, **kwargs):

        session_asset(request)
        userinfo = request.session["UserData"]["last_name"] + ' - %s' % request.session["UserData"]["username"]
        username = request.session["UserData"]["last_name"]

        if perm_check(request, *args, **kwargs):  #调用上面的权限验证方法
            return fun(request, *args, **kwargs)
        return render(request, 'base/403.html', locals())
    return wapper