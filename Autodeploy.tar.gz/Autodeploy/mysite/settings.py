# -*- coding:utf-8 -*-
#!/usr/bin/env python
__author__ = '001163'


"""
Django settings for mysite project.

For more information on this file, see
https://docs.djangoproject.com/en/1.7/topics/settings/

For the full list of settings and their values, see
https://docs.djangoproject.com/en/1.7/ref/settings/
"""

# Build paths inside the project like this: os.path.join(BASE_DIR, ...)
import os
import ldap
from django_auth_ldap.config import LDAPSearch, GroupOfNamesType

BASE_DIR = os.path.dirname(os.path.dirname(__file__))

# Quick-start development settings - unsuitable for production
# See https://docs.djangoproject.com/en/1.7/howto/deployment/checklist/

# SECURITY WARNING: keep the secret key used in production secret!
SECRET_KEY = 'j5y@3bh7$y+gob4tda#ji2=a74bf#gxr5)%japz*d0a28%b2_)'

# SECURITY WARNING: don't run with debug turned on in production!

DEBUG = True

TEMPLATE_DEBUG = True

ALLOWED_HOSTS = ["*"]


# Application definition
INSTALLED_APPS = (
    'django.contrib.admin',
    'django.contrib.auth',
    'django.contrib.contenttypes',
    'django.contrib.sessions',
    'django.contrib.messages',
    'django.contrib.staticfiles',
    'autodeploy',
    'pagination',
)

MIDDLEWARE_CLASSES = (
    'django.contrib.sessions.middleware.SessionMiddleware',
    'django.middleware.common.CommonMiddleware',
    # 'django.middleware.csrf.CsrfViewMiddleware',
    'django.contrib.auth.middleware.AuthenticationMiddleware',
    'django.contrib.auth.middleware.SessionAuthenticationMiddleware',
    'django.contrib.messages.middleware.MessageMiddleware',
    'django.middleware.clickjacking.XFrameOptionsMiddleware',
)


ROOT_URLCONF = 'mysite.urls'

WSGI_APPLICATION = 'mysite.wsgi.application'


CONTEXT_PROCESSORS = [
    'django.template.context_processors.debug',
    'django.template.context_processors.request',
    'django.contrib.auth.context_processors.auth',
    'django.contrib.messages.context_processors.messages',
    'autodeploy.views.global_settings',
]

TEMPLATE_DIRS = (
    os.path.join(BASE_DIR, 'templates'),
)

TEMPLATE_PATH = os.path.join(BASE_DIR, 'templates')

TEMPLATES = [
    # {
    #     'BACKEND': 'django.template.backends.django.DjangoTemplates',
    #     'DIRS': [os.path.join(BASE_DIR, 'templates'),],
    #     'APP_DIRS': True,
    #     'OPTIONS': {
    #         'context_processors': CONTEXT_PROCESSORS,
    #     },
    # },
    {
        'BACKEND': 'autodeploy.backends.Jinja2Backend',
        'DIRS': [os.path.join(BASE_DIR, 'templates'),],
        'APP_DIRS': True,
        'OPTIONS': {
            'environment': 'autodeploy.jinja2_env.environment',
            'context_processors': CONTEXT_PROCESSORS,
        },
    },
]

# Database
# https://docs.djangoproject.com/en/1.7/ref/settings/#databases

DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.mysql',
        'NAME': 'autodeploy_new',
        'USER': 'root',
        'PASSWORD': '123456',
        'HOST': '127.0.0.1',
        'PORT': '3306',
    }
}

# Internationalization
# https://docs.djangoproject.com/en/1.7/topics/i18n/

LANGUAGE_CODE = 'en-us'

TIME_ZONE = 'Asia/Shanghai'

USE_I18N = True

USE_L10N = True

USE_TZ = False


# Static files (CSS, JavaScript, Images)
# https://docs.djangoproject.com/en/1.7/howto/static-files/


# 系统运行基目录
# BASE_DIR = '/app/deploy_apps/'

# LOGIN_URL = '/login/'


# 任务日志上传存放路径
BATCH_LOG_BASE_URL = os.path.join(BASE_DIR, 'batchlogs')

# STATIC_URL = '/static/'
#
#
# STATICFILES_DIRS = (
#     # os.path.join(BASE_DIR, "static").replace("\\","/"),
# )
#
# STATIC_ROOT = os.path.join(BASE_DIR, "static/")


STATIC_URL = '/static/'

# STATIC_ROOT = os.path.join(BASE_DIR, "static")

STATICFILES_DIRS = (
    os.path.join(BASE_DIR, "static").replace("\\","/"),
)

LOGIN_URL = '/login'

X_FRAME_OPTIONS = 'ALLOWALL'

# LDAP登录验证
AUTH_LDAP_SERVER_URI = 'ldap://xxxxxx:3268'
AUTH_LDAP_BIND_DN = 'CN=svn_admin,CN=Managed Service Accounts,DC=fcbox,DC=com'
AUTH_LDAP_BIND_PASSWORD = 'xxxxxx'
OU = unicode('OU=Fcbox Users,DC=fcbox,DC=com', 'utf8')

AUTH_LDAP_USER_SEARCH = LDAPSearch(OU, ldap.SCOPE_SUBTREE, "(&(objectClass=person)(sAMAccountName=%(user)s))")

AUTH_LDAP_USER_ATTR_MAP = {
    "first_name": "givenName",
    "last_name": "sn",
    "email": "mail",
    "first_name": "telephoneNumber",
}

AUTH_LDAP_ALWAYS_UPDATE_USER = True

AUTHENTICATION_BACKENDS = (
    'django_auth_ldap.backend.LDAPBackend',
    'django.contrib.auth.backends.ModelBackend',
)

# 更新及流程相关字典
DEPLOY_STATUS = ('审批中', '审核驳回', '待更新', '更新中', '更新成功', '更新异常', '取消更新')
DEPLOY_ENV = ('测试环境', '灰度环境', '生产环境')
ADD_DEPLOY_TYPE = ('全量更新', '增量更新')
DEPLOY_TYPE = ('全量更新', '增量更新', '全量回滚', '增量回滚')
MESSAGE_TYPE = ('不通知', '邮件通知', '短信通知', '邮件短信均通知')
NODE_TASK_STATUS = ('排队中', '更新中', '更新异常', '更新成功')
DEPLOY_PLAN = ('手动更新', '自动更新(审批后即进行)')

# 用户操作审计相关字典
USER_ACTION_CONVERT = {
    'adddeploy': '发起更新',
    'addrollback': '发起回滚',
    'rollback': '回滚',
    'login': '登录',
    'logout': '登出',
    'ldapsync': 'LDAP同步',
    'editrole': '编辑角色',
    'addserver': '增加服务器',
    'editserver': '编辑服务器',
    'addsite': '增加站点类别',
    'editsite': '编辑站点类别',
    'addapp': '增加项目',
    'editapp': '编辑项目',
    'delappnode': '删除项目节点',
    'tomcat_task': '添加Tomcat任务',
    'approve_success': '审批通过',
    'approve_notgo': '审批驳回',
    'dodeploy': '操作更新',
    'addappnode': '添加项目节点',
    'editdeploy': '编辑更新',
    'notgo': '取消更新'
}

# Ansible 服务器登录信息用于中间件部署
ANSIBLE_INFO = {
    'HOST':'192.168.137.3',
    'USER':'root',
    'PASSWD':'xxxxx'
}

DATETIME_FORMAT = 'Y-m-d H:i:sO'

DATE_FORMAT = 'Y-m-d'

BROKER_URL = 'amqp://guest:xxxx@xxxxx:5672//'
# CELERY_RESULT_BACKEND = "amqp"
# BACKEND_URL = 'amqp://guest:guest@10.204.56.42:5672/'
