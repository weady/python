from django.conf.urls import url
from django.contrib import admin
from autodeploy import views

urlpatterns = [
    url(r'^$', views.login),
    url(r'^index$', views.index),
    url(r'^test$', views.test),
    url(r'^login$', views.login),
    url(r'^accounts/login/$', views.login),
    # url(r'^accounts/login/$', 'django.contrib.auth.views.login'),
    url(r'^logout$', views.logout),
    url(r'^deploy$', views.deploy, name="deploy"),
    url(r'^deploy_grey$', views.deploy_grey, name="deploy_grey"),
    url(r'^deploy_his$', views.deploy_his, name="deploy_his"),
    url(r'^adddeploy$', views.adddeploy, name="adddeploy"),
    url(r'^adddeploy_grey$', views.adddeploy_grey, name="adddeploy_grey"),
    url(r'^deploygo/(.+)/$', views.deploygo, name="deploygo"),
    url(r'^approve_success/(.+)/$', views.approve_success, name="approve_success"),
    url(r'^approve_notgo/(.+)/$', views.approve_notgo, name="approve_notgo"),
    url(r'^dodeploy/(.+)/$', views.dodeploy, name="dodeploy"),
    url(r'^notgo/(.+)/$', views.notgo, name="notgo"),
    url(r'^rollback/(.+)/$', views.rollback, name="rollback"),
    url(r'^task', views.task),
    url(r'^ac_logs', views.ac_logs, name="ac_logs"),
    url(r'^api/v1.0/batch_task/modify_status/(.+)$', views.modify_batch_task_status, name="modify_batch_task_status"),
    url(r'^batchlog', views.batchlog, name="batchlog"),
    url(r'^admin/', admin.site.urls),

   # deploy middleware
    url(r'^deploysoft$',views.deploysoft),
    url(r'^deploysoft/install$',views.installsoft),
    url(r'^deploysoft/flushlog$',views.flushlog),
    url(r'^deploysoft/getversion$',views.getsoft_version),
    # url(r'^add_publisher/$', views.add_publisher),
    # url(r'^add_publisher/$', views.add_publisher, name="add_publisher"),
]
