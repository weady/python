#!/bin/bash

echo "do rollback task" >>/tmp/2.txt
#a=`curl -i -H "Content-Type: application/json" -X POST -d '{"status":4}' http://10.204.56.42:5000/api/v1.0/batch_task/modify_status/ROA-fcbox-$1`
a=`curl -i -H "Content-Type: application/json" -X POST -d '{"status":4}' http://aud2.fcbox.com/api/v1.0/batch_task/modify_status/ROA-fcbox-$1`
echo $1
