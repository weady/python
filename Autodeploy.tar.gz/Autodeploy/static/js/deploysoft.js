// 部署按钮
$('.addapp .deploysoft').click(function(){
	// 获取部署的中间件名称
	var SOFTNAME=$('.addapp .soft input:radio:checked').val()
	// 获取IP列表
	var IPLIST=$('.addapp .ip_list').val()

	// 获取配置文件内容
	var CONFIGURE=$('.addapp .configure').val()

	//日志文件名
	var LOGFILE=$('.addapp .deploy_report #logname').val()
    var VER = $('.version option:selected').val();
	if (SOFTNAME != '' &&IPLIST != '' && CONFIGURE != '' && VER != '') {
        if (confirm('你确定要部署中间件'+SOFTNAME+'吗?')) {
                $.ajax({
                    url: 'deploysoft/install',
                    type: 'POST',
                    dataType: 'json',
                    data: {
                        softname:SOFTNAME,
                        ips:IPLIST,
                        configure:CONFIGURE,
                        logfile:LOGFILE,
                        ver:VER,
                    },
                    success:function(data,status){
                        alert(data)
                    }
                });
            }
        else{
            alert('取消部署')
            }
    }
    else{
        alert('部署参数缺失');
        }

        return false;
});

// 重置按钮
$('.addapp .cancle').click(function(){
	var SOFTNAME=$('.addapp .soft input:radio:checked').val('')
	var IPLIST=$('.addapp .ip_list').val('')
	var CONFIGURE=$('.addapp .configure').val('')	
})


// 日期格式
Date.prototype.Format = function (fmt) { //author: meizz
    var o = {
        "M+": this.getMonth() + 1, //月份
        "d+": this.getDate(), //日
        "h+": this.getHours(), //小时
        "m+": this.getMinutes(), //分
        "s+": this.getSeconds(), //秒
        "q+": Math.floor((this.getMonth() + 3) / 3), //季度
        "S": this.getMilliseconds() //毫秒
    };
    if (/(y+)/.test(fmt)) fmt = fmt.replace(RegExp.$1, (this.getFullYear() + "").substr(4 - RegExp.$1.length));
    for (var k in o)
    if (new RegExp("(" + k + ")").test(fmt)) fmt = fmt.replace(RegExp.$1, (RegExp.$1.length == 1) ? (o[k]) : (("00" + o[k]).substr(("" + o[k]).length)));
    return fmt;
}
//ajax定时刷新日志,实现滚动展示效果

var logtext = ""
var old_data = ""
var old_num = 0
top.runajax = function(logfile){
        window.time_flags;
        if (typeof(time_flags) == 'undefined'){
             time_flags = new Date().Format("yyyy-MM-dd hh:mm:ss");
        }

        $.ajax({
            url: 'deploysoft/flushlog',
            type: 'POST',
            dataType: 'json',
            data:{
            logfile:logfile,
            time_flag:time_flags
            },
            success:function(data,status){
            	new_num = data.length
            	if (new_num >old_num) {
            		number = new_num - old_num
            		for (var i = number; i < data.length; i++) {
           				$('.loginfo').append(data[i])
            		}
            		old_num =new_num
            	} else if (new_num == old_num){
            		$('.loginfo').empty()
            		for (var i = 0; i < data.length; i++) {
           				$('.loginfo').append(data[i])
            		}
            		old_num = new_num
            	}

	            $('.deploy_report').scrollTop( $('.deploy_report')[0].scrollHeight );
	            return;
              }
        });
}

// 选择中间件后获取对应版本信息
function get_version(){
    var versioninfo = ''
    var tag_type = $('.soft :radio:checked').val()
    $('.addapp .version').empty();
    $.ajax({
        url: 'deploysoft/getversion',
        type: 'POST',
        dataType: 'json',
        data:{
            tag:tag_type,
        },
        success:function(data,status){
            for (var i = 0; i < data.length; i++) {
                if (data[i]) {
                    versioninfo+='<option>'+data[i]+'</option>'
                }
            }
                $('.addapp .version').append(versioninfo);
        }

    });
 }